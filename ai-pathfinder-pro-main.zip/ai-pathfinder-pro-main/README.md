# AI Pathfinder Pro

Build a complete, modern, responsive educational web app for the college subject 'Foundation of Artificial Intelligence' titled 'AI RESCUE MISSION: Find the Best Path Using Heuristic Search'.

Key Architecture & Constraints:
- Pure client-side implementation: zero backend, zero databases, zero external AI APIs, zero machine learning/deep learning.
- Authentic, real A* search algorithm and Breadth-First Search (BFS) implemented directly in TypeScript/JavaScript without faking paths or statistics.
- Dark navy academic/futuristic theme with cyan, purple, and emerald neon accents, clean typography, glowing grid cells, and smooth animations.

Sections & Features to implement:
1. Sticky Header & Navigation:
   - Logo 'AI RESCUE MISSION', navigation links: Home, Problem, A* Simulator, Heuristic, Challenges, BFS vs A*, AI Concepts, Code Logic, About.

2. Hero / Landing Section:
   - Title: 'AI RESCUE MISSION'
   - Subtitle: 'Can you guide the rescue robot using Artificial Intelligence?'
   - Description: 'An interactive demonstration of Informed Search Strategies using the A* algorithm and heuristic functions.'
   - CTA buttons: 'START RESCUE' (scrolls to simulator) & 'LEARN HEURISTICS' (scrolls to theory)
   - 4 Feature Cards: 🧠 Informed Search, 📏 Heuristic Function, ⭐ A* Algorithm, 🗺️ Path Finding
   - Short problem statement overview card.

3. Search Problem Formulation Section:
   - Formally breaks down: Initial State, Goal State, Search Space, Actions (Up, Down, Left, Right), Path Cost (c=1 per move), Constraints (Obstacles).
   - Visual cards explaining each component of the state-space formulation.

4. Main Interactive Grid Simulator (The Core Feature):
   - Interactive 10x10 grid (with options for 10x10 up to 15x15).
   - Cell types: Start (🟢 robot), Goal (🔴 emergency flag/station), Obstacles (⬛ walls/rubble), Unvisited (⬜ subtle dark grid), Open List (🟡 amber glow), Explored/Closed (🔵 cyan pulse), Final Path (⭐ emerald green with path animation).
   - Mode controls: Place Start, Place Goal, Draw/Erase Obstacles (click & drag supported).
   - Action buttons: 'RUN A*', 'STEP FORWARD' (step-by-step debugger), 'RESET', 'RANDOM MAP', 'CLEAR OBSTACLES', and animation speed slider (Slow, Medium, Fast, Instant).
   - Real-time status badge: 'Idle', 'Searching...', 'Goal Reached!', or 'No Path Found!'.

5. Heuristic Analyzer Panel (Beside the Grid):
   - Shows live inspection on hovered or clicked cell:
     - Current Node: (x, y)
     - Goal: (x, y)
     - Actual Cost: g(n)
     - Heuristic: h(n) = |x - goalX| + |y - goalY| (with Manhattan calculation formula visible)
     - Total Cost: f(n) = g(n) + h(n)
   - Directional indicator pointing towards the goal.
   - Explanatory note: 'h(n) estimates the remaining distance from the current node to the goal.'

6. Search Statistics & Results:
   - Real-time / final counters: Path Found (Yes/No), Path Cost, Nodes Explored, Nodes in Open List, Execution Time (ms), Heuristic Used (Manhattan Distance), Formula badge f(n) = g(n) + h(n).

7. Dynamic Step-by-Step A* Trace Log:
   - Collapsible/expandable execution table recording every step from the actual run:
     - Step #, Node (x,y), g(n), h(n), f(n), Parent Node, Status (Added to Open / Explored).
     - Allows students to examine the exact mathematical priority queue behavior.

8. Heuristic Deep Dive & Interactive Visualizer:
   - 'Why Does a Heuristic Help?' section.
   - Interactive demo showing why informed search prunes the search tree compared to blind search.
   - Comparison of Heuristic Functions: Manhattan (|Δx| + |Δy|), Euclidean (√(Δx² + Δy²)), and Chebyshev (max(|Δx|, |Δy|)) with interactive diagram.
   - Admissibility card: explaining h(n) <= h*(n) and why Manhattan distance is admissible for orthogonal grid navigation.

9. BFS vs A* Head-to-Head Comparison:
   - 'Uninformed Search vs Informed Search'
   - Ability to run Breadth-First Search (BFS) and A* on the exact same obstacle configuration.
   - Side-by-side or comparison card displaying: Nodes Explored, Path Length, Execution Steps.
   - Clear educational note highlighting that BFS explores uniformly in all directions while A* is guided toward the goal by h(n).

10. 5 Predefined Game Challenges:
    - Challenge 1: Easy Rescue (simple obstacles)
    - Challenge 2: Blocked Route (direct path blocked, requires detour)
    - Challenge 3: Maze Rescue (corridors and dead ends)
    - Challenge 4: Multiple Routes (competing paths of equal cost)
    - Challenge 5: Expert Rescue (complex urban disaster zone)
    - One-click load button for each challenge, displaying difficulty, start/goal coordinates, and tracked completion stats.

11. Foundation of AI Academic Theory Sections:
    - 10 Key Concepts cards (State Space, Initial State, Goal State, Operators, Search Space, Path Cost, Informed Search, Heuristic Function, A* Algorithm, Optimal Solution).
    - 'Where is AI Used in Our Website?' flowchart tracking: Problem -> State Space -> Initial State -> Generate Neighbors -> Calculate g/h/f -> Select Lowest f(n) -> Goal -> Optimal Path.
    - Pseudocode flowchart for A* search with student-friendly explanations.
    - Real-world applications: GPS Route Planning, Robot Navigation, Game AI, Emergency Logistics, Flight Path Planning.
    - Technology stack breakdown emphasizing clean educational frontend architecture with zero external APIs or ML.
    - Final Learning Outcomes checklist for students.

Ensure high visual polish, accessible responsive layout for mobile and desktop, tooltips, sound/visual feedback on run, and crystal-clear educational value.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4194c85e-d9a4-4768-b668-2873e092f522).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
