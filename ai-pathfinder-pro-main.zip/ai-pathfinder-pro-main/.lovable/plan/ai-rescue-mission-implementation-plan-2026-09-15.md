# AI Rescue Mission — Implementation Plan

## Goal
Build a polished, single-page educational experience where students can learn heuristic search by editing a rescue grid, running authentic A* and BFS, inspecting every search decision, and comparing both algorithms on identical maps. Everything runs locally in the browser with no accounts, backend, database, external APIs, machine learning, or generated search results.

## Experience and visual direction
- Use a dark navy academic control-room aesthetic with cyan search states, purple theory accents, emerald paths, amber open-list cells, restrained glow, and a subtle technical grid texture.
- Keep the simulator as the visual and functional centerpiece, with dense but readable controls on desktop and a stacked, touch-friendly layout on mobile.
- Use semantic color tokens throughout, crisp geometric typography, compact cards, clear focus states, reduced-motion support, and accessible labels/tooltips.
- Add restrained motion for node expansion, path reveal, status changes, and section transitions; provide gentle synthesized sound cues through the browser when a run starts, succeeds, or fails.

## Application structure
- Replace the placeholder home screen with one complete scrolling experience and sticky navigation anchors: Home, Problem, A* Simulator, Heuristic, Challenges, BFS vs A*, AI Concepts, Code Logic, and About.
- Add a compact responsive header with active-section indication and a mobile navigation drawer.
- Build reusable feature modules for the search engine, grid, controls, analyzer, statistics, trace log, challenges, comparisons, diagrams, and academic content.
- Add app-specific page metadata, social metadata, and a concise footer/About section.

## Authentic search engine
- Implement pure TypeScript A* with a real priority queue ordered by `f(n) = g(n) + h(n)`, deterministic tie-breaking, parent tracking, closed/open sets, four-direction movement, unit edge cost, and Manhattan distance.
- Implement pure TypeScript BFS with a FIFO queue, parent tracking, and the same movement and obstacle rules.
- Return actual event streams from both engines so animations, statistics, comparison results, and trace rows all derive from the executed algorithms.
- Support success, no-path, start-equals-goal, changed grid size, reset, and interrupted/restarted runs without stale timers.

## Simulator
- Render an editable 10×10 grid with selectable sizes through 15×15 and stable square cells at every viewport.
- Support Place Start, Place Goal, Draw Obstacles, and Erase modes; obstacle drawing/erasing works by click-and-drag and touch movement.
- Show distinct states for start robot, emergency goal, obstacle, unvisited, open list, explored/closed, current node, and final path.
- Provide Run A*, Step Forward, Reset, Random Map, Clear Obstacles, and four animation speeds: Slow, Medium, Fast, Instant.
- Keep mutually exclusive actions disabled while animation is active and expose Idle, Searching, Goal Reached, and No Path Found status clearly.
- Generate random maps that preserve start and goal and use a bounded obstacle density; results still depend entirely on the real algorithm.

## Analyzer, statistics, and trace
- Let hover or selection inspect any cell and show its coordinates, goal coordinates, actual `g(n)` when known, Manhattan formula substitution, `h(n)`, `f(n)`, and a directional arrow toward the goal.
- Show live/final values for path found, path cost, explored nodes, open-list size, execution time, heuristic name, and the A* formula.
- Record actual queue events in a collapsible trace table with step, node, g/h/f, parent, and Added to Open or Explored status.
- Keep the trace usable on phones with horizontal scrolling and a compact summary when collapsed.

## Educational sections
- Create the problem-formulation area for initial state, goal state, search space, actions, unit path cost, and obstacles.
- Build a heuristic deep dive with an interactive coordinate selector comparing Manhattan, Euclidean, and Chebyshev calculations and diagrams.
- Add a focused visual explanation of informed pruning and an admissibility panel showing `h(n) ≤ h*(n)` for orthogonal movement.
- Add ten AI concept cards, the website’s problem-to-optimal-path process flow, student-friendly A* pseudocode, five real-world applications, the zero-API frontend architecture, and a final learning-outcomes checklist.

## BFS vs A* comparison
- Run BFS and A* against a cloned snapshot of the exact current grid.
- Present comparable, real results for nodes explored, path length, execution steps, and success state, with compact visual bars for exploration effort.
- Explain the observable difference: BFS expands uniformly while A* prioritizes nodes using the heuristic.

## Challenges
- Add five deterministic layouts: Easy Rescue, Blocked Route, Maze Rescue, Multiple Routes, and Expert Rescue.
- Each challenge shows difficulty, start/goal coordinates, and session-only completion results, with one-click loading into the simulator.
- Challenge completion statistics remain in browser memory for the current visit only, matching the zero-persistence requirement.

## Validation
- Add focused tests for A*, BFS, shortest-path correctness, no-path handling, deterministic trace generation, and heuristic calculations.
- Verify the preview at desktop and mobile widths, including drag editing, stepping, running, reset/random behavior, challenge loading, analyzer updates, comparison results, trace expansion, navigation, and no-overlap layout.
- Confirm the final project builds cleanly and has no runtime or console errors.
