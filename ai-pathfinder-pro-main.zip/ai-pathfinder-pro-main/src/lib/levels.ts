import type { Point } from "./search";

export type Level = {
  id: number;
  name: string;
  codename: string;
  brief: string;
  size: number;
  start: Point;
  goal: Point;
  aiDelay: number;
  obstacles: string[];
};

const cells = (points: Array<[number, number]>) => points.map(([x, y]) => `${x},${y}`);

export const levels: Level[] = [
  {
    id: 1,
    name: "Sector 1",
    codename: "Clear Streets",
    brief: "Light debris only. Learn the controls and beat the drone to the beacon.",
    size: 10,
    start: { x: 1, y: 8 },
    goal: { x: 8, y: 1 },
    aiDelay: 620,
    obstacles: cells([[3,8],[3,7],[3,6],[3,5],[4,5],[5,5],[6,5]]),
  },
  {
    id: 2,
    name: "Sector 2",
    codename: "Collapsed Highway",
    brief: "The direct avenue is sealed by a fallen overpass. Find the gap.",
    size: 11,
    start: { x: 0, y: 5 },
    goal: { x: 10, y: 5 },
    aiDelay: 520,
    obstacles: cells([[4,0],[4,1],[4,2],[4,3],[4,4],[4,5],[4,6],[4,7],[4,9],[4,10],[7,1],[7,2],[7,3],[7,4],[7,5],[7,6],[7,7],[7,8],[7,9],[7,10]]),
  },
  {
    id: 3,
    name: "Sector 3",
    codename: "Urban Ruins Maze",
    brief: "Narrow corridors and dead ends. One wrong turn burns precious battery.",
    size: 12,
    start: { x: 0, y: 11 },
    goal: { x: 11, y: 0 },
    aiDelay: 440,
    obstacles: cells([[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],[2,7],[2,8],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[4,9],[6,1],[6,2],[6,3],[6,4],[6,5],[6,6],[8,4],[8,5],[8,6],[8,7],[8,8],[8,9],[10,1],[10,2],[10,3],[10,4]]),
  },
  {
    id: 4,
    name: "Sector 4",
    codename: "Downtown Gridlock",
    brief: "A city block grid of wreckage with several equal-cost routes.",
    size: 13,
    start: { x: 0, y: 12 },
    goal: { x: 12, y: 0 },
    aiDelay: 380,
    obstacles: cells([[2,2],[3,2],[4,2],[2,3],[2,4],[6,0],[6,1],[6,2],[6,3],[6,5],[6,6],[6,7],[8,8],[9,8],[10,8],[8,9],[8,10],[4,8],[4,9],[4,10],[5,10],[10,2],[10,3],[10,4],[10,5],[1,7],[2,7],[3,7]]),
  },
  {
    id: 5,
    name: "Sector 5",
    codename: "Mega Catastrophe",
    brief: "A devastated megacity. The drone's heuristic really earns its keep here.",
    size: 15,
    start: { x: 0, y: 14 },
    goal: { x: 14, y: 0 },
    aiDelay: 300,
    obstacles: cells([[2,0],[2,1],[2,2],[2,3],[2,4],[2,6],[2,7],[2,8],[2,9],[2,10],[2,11],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[4,9],[4,10],[4,11],[4,12],[6,0],[6,1],[6,2],[6,3],[6,4],[6,6],[6,7],[6,8],[6,9],[6,10],[6,11],[8,3],[8,4],[8,5],[8,6],[8,7],[8,8],[8,9],[8,10],[8,12],[8,13],[10,1],[10,2],[10,3],[10,4],[10,5],[10,6],[10,7],[10,9],[10,10],[10,11],[10,12],[12,3],[12,4],[12,5],[12,6],[12,7],[12,8],[12,9],[12,10],[12,11],[12,12]]),
  },
];
