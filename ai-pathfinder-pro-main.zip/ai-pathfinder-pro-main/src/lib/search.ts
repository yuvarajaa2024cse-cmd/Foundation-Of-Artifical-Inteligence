export type Point = { x: number; y: number };
export type SearchStatus = "open" | "explored";

export type SearchEvent = {
  step: number;
  node: Point;
  g: number;
  h: number;
  f: number;
  parent: Point | null;
  status: SearchStatus;
  openSize: number;
};

export type SearchResult = {
  found: boolean;
  path: Point[];
  cost: number;
  explored: number;
  steps: number;
  duration: number;
  events: SearchEvent[];
  scores: Record<string, number>;
};

export const keyOf = ({ x, y }: Point) => `${x},${y}`;
export const manhattan = (a: Point, b: Point) => Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
export const euclidean = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
export const chebyshev = (a: Point, b: Point) => Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));

const neighbors = (point: Point, size: number, obstacles: Set<string>) =>
  [
    { x: point.x + 1, y: point.y },
    { x: point.x, y: point.y + 1 },
    { x: point.x - 1, y: point.y },
    { x: point.x, y: point.y - 1 },
  ].filter(({ x, y }) => x >= 0 && y >= 0 && x < size && y < size && !obstacles.has(`${x},${y}`));

function reconstruct(parent: Map<string, Point>, end: Point) {
  const path = [end];
  let cursor = end;
  while (parent.has(keyOf(cursor))) {
    const next = parent.get(keyOf(cursor));
    if (!next) break;
    path.unshift(next);
    cursor = next;
  }
  return path;
}

export function runAStar(size: number, start: Point, goal: Point, obstacles: Set<string>): SearchResult {
  const began = performance.now();
  const open: Array<{ point: Point; g: number; h: number; order: number }> = [];
  const closed = new Set<string>();
  const parent = new Map<string, Point>();
  const scores: Record<string, number> = { [keyOf(start)]: 0 };
  const events: SearchEvent[] = [];
  let order = 0;
  const startH = manhattan(start, goal);
  open.push({ point: start, g: 0, h: startH, order: order++ });
  events.push({ step: 1, node: start, g: 0, h: startH, f: startH, parent: null, status: "open", openSize: 1 });

  while (open.length) {
    open.sort((a, b) => a.g + a.h - (b.g + b.h) || a.h - b.h || a.order - b.order);
    const current = open.shift();
    if (!current) break;
    const currentKey = keyOf(current.point);
    if (closed.has(currentKey)) continue;
    closed.add(currentKey);
    events.push({ step: events.length + 1, node: current.point, g: current.g, h: current.h, f: current.g + current.h, parent: parent.get(currentKey) ?? null, status: "explored", openSize: open.length });
    if (currentKey === keyOf(goal)) {
      const path = reconstruct(parent, goal);
      return { found: true, path, cost: path.length - 1, explored: closed.size, steps: events.length, duration: performance.now() - began, events, scores };
    }
    for (const next of neighbors(current.point, size, obstacles)) {
      const nextKey = keyOf(next);
      if (closed.has(nextKey)) continue;
      const tentative = current.g + 1;
      if (tentative >= (scores[nextKey] ?? Number.POSITIVE_INFINITY)) continue;
      parent.set(nextKey, current.point);
      scores[nextKey] = tentative;
      const h = manhattan(next, goal);
      open.push({ point: next, g: tentative, h, order: order++ });
      events.push({ step: events.length + 1, node: next, g: tentative, h, f: tentative + h, parent: current.point, status: "open", openSize: open.length });
    }
  }
  return { found: false, path: [], cost: 0, explored: closed.size, steps: events.length, duration: performance.now() - began, events, scores };
}

export function runBfs(size: number, start: Point, goal: Point, obstacles: Set<string>): SearchResult {
  const began = performance.now();
  const queue: Point[] = [start];
  const seen = new Set([keyOf(start)]);
  const parent = new Map<string, Point>();
  const scores: Record<string, number> = { [keyOf(start)]: 0 };
  const events: SearchEvent[] = [];
  while (queue.length) {
    const current = queue.shift();
    if (!current) break;
    const g = scores[keyOf(current)] ?? 0;
    events.push({ step: events.length + 1, node: current, g, h: 0, f: g, parent: parent.get(keyOf(current)) ?? null, status: "explored", openSize: queue.length });
    if (keyOf(current) === keyOf(goal)) {
      const path = reconstruct(parent, goal);
      return { found: true, path, cost: path.length - 1, explored: events.length, steps: events.length, duration: performance.now() - began, events, scores };
    }
    for (const next of neighbors(current, size, obstacles)) {
      const nextKey = keyOf(next);
      if (seen.has(nextKey)) continue;
      seen.add(nextKey);
      parent.set(nextKey, current);
      scores[nextKey] = g + 1;
      queue.push(next);
    }
  }
  return { found: false, path: [], cost: 0, explored: events.length, steps: events.length, duration: performance.now() - began, events, scores };
}