import type { Point } from "./search";

export type Challenge = {
  id: number;
  name: string;
  difficulty: string;
  description: string;
  size: number;
  start: Point;
  goal: Point;
  obstacles: string[];
};

const cells = (points: Array<[number, number]>) => points.map(([x, y]) => `${x},${y}`);

export const challenges: Challenge[] = [
  { id: 1, name: "Easy Rescue", difficulty: "Beginner", description: "A gentle introduction with one clear detour.", size: 10, start: { x: 1, y: 8 }, goal: { x: 8, y: 1 }, obstacles: cells([[3,8],[3,7],[3,6],[3,5],[4,5],[5,5],[6,5],[7,5]]) },
  { id: 2, name: "Blocked Route", difficulty: "Intermediate", description: "The obvious route is sealed. Search for the opening.", size: 10, start: { x: 1, y: 5 }, goal: { x: 8, y: 5 }, obstacles: cells([[4,1],[4,2],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[5,1],[5,8]]) },
  { id: 3, name: "Maze Rescue", difficulty: "Advanced", description: "Navigate corridors, turns, and deceptive dead ends.", size: 12, start: { x: 0, y: 11 }, goal: { x: 11, y: 0 }, obstacles: cells([[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],[2,7],[2,8],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[4,9],[6,1],[6,2],[6,3],[6,4],[6,5],[6,6],[8,4],[8,5],[8,6],[8,7],[8,8],[8,9],[10,1],[10,2],[10,3],[10,4]]) },
  { id: 4, name: "Multiple Routes", difficulty: "Strategic", description: "Several routes compete with equal total cost.", size: 12, start: { x: 1, y: 6 }, goal: { x: 10, y: 6 }, obstacles: cells([[5,2],[5,3],[5,4],[5,5],[5,6],[5,7],[5,8],[5,9],[7,2],[7,3],[7,4],[7,5],[7,6],[7,7],[7,8],[7,9]]) },
  { id: 5, name: "Expert Rescue", difficulty: "Expert", description: "A dense urban zone rewards careful heuristic guidance.", size: 15, start: { x: 0, y: 14 }, goal: { x: 14, y: 0 }, obstacles: cells([[2,0],[2,1],[2,2],[2,3],[2,4],[2,6],[2,7],[2,8],[2,9],[2,10],[2,11],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[4,9],[4,10],[4,11],[4,12],[6,0],[6,1],[6,2],[6,3],[6,4],[6,6],[6,7],[6,8],[6,9],[6,10],[6,11],[8,3],[8,4],[8,5],[8,6],[8,7],[8,8],[8,9],[8,10],[8,12],[8,13],[10,1],[10,2],[10,3],[10,4],[10,5],[10,6],[10,7],[10,9],[10,10],[10,11],[10,12],[12,3],[12,4],[12,5],[12,6],[12,7],[12,8],[12,9],[12,10],[12,11],[12,12]]) },
];