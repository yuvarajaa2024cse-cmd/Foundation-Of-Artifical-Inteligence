import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, Battery, Bot, ChevronRight, Eraser, Flag, Gauge, Pencil, Play, Radar, RotateCcw,
  Shuffle, Timer, Trophy, User, Volume2, VolumeX, Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { levels, type Level } from "@/lib/levels";
import { keyOf, manhattan, runAStar, type Point, type SearchResult } from "@/lib/search";

type Phase = "ready" | "countdown" | "racing" | "over";
type Outcome = "player" | "ai" | "drained" | null;

let audio: AudioContext | null = null;
function sfx(kind: "move" | "beep" | "go" | "win" | "lose" | "ping", on: boolean) {
  if (!on || typeof window === "undefined") return;
  const Ctx = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  try {
    audio = audio ?? new Ctx();
    if (audio.state === "suspended") void audio.resume();
    const table: Record<string, [number, number, number, OscillatorType]> = {
      move: [220, 0.05, 0.03, "square"],
      beep: [440, 0.12, 0.05, "sine"],
      go: [780, 0.25, 0.06, "sine"],
      win: [880, 0.5, 0.06, "triangle"],
      lose: [140, 0.5, 0.06, "sawtooth"],
      ping: [1200, 0.16, 0.035, "sine"],
    };
    const [freq, length, vol, type] = table[kind] ?? table["move"]!;
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audio.currentTime);
    if (kind === "win") osc.frequency.exponentialRampToValueAtTime(freq * 2, audio.currentTime + length);
    if (kind === "lose") osc.frequency.exponentialRampToValueAtTime(freq / 2, audio.currentTime + length);
    gain.gain.setValueAtTime(vol, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + length);
    osc.connect(gain).connect(audio.destination);
    osc.start();
    osc.stop(audio.currentTime + length + 0.02);
  } catch { /* audio unavailable */ }
}

const budgetFor = (optimal: number) => Math.max(8, Math.round(optimal * 1.6) + 4);
const fmt = (ms: number) => `${Math.floor(ms / 1000).toString().padStart(2, "0")}.${Math.floor((ms % 1000) / 10).toString().padStart(2, "0")}`;

export function RescueRace() {
  const [level, setLevel] = useState<Level>(levels[0]!);
  const [custom, setCustom] = useState(false);
  const [size, setSize] = useState(level.size);
  const [start, setStart] = useState<Point>(level.start);
  const [goal, setGoal] = useState<Point>(level.goal);
  const [obstacles, setObstacles] = useState<Set<string>>(new Set(level.obstacles));
  const [paint, setPaint] = useState<"draw" | "erase">("draw");
  const [dragging, setDragging] = useState(false);

  const [phase, setPhase] = useState<Phase>("ready");
  const [count, setCount] = useState(3);
  const [player, setPlayer] = useState<Point>(level.start);
  const [trail, setTrail] = useState<string[]>([keyOf(level.start)]);
  const [steps, setSteps] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [aiIndex, setAiIndex] = useState(0);
  const [plan, setPlan] = useState<SearchResult | null>(null);
  const [outcome, setOutcome] = useState<Outcome>(null);
  const [radar, setRadar] = useState(false);
  const [sound, setSound] = useState(true);
  const [cleared, setCleared] = useState<Record<number, boolean>>({});

  const startedAt = useRef(0);
  const phaseRef = useRef<Phase>("ready");
  phaseRef.current = phase;

  const preview = useMemo(() => runAStar(size, start, goal, obstacles), [size, start, goal, obstacles]);
  const battery = budgetFor(preview.found ? preview.cost : size * 2);
  const remaining = Math.max(0, battery - steps);

  const loadLevel = useCallback((next: Level) => {
    setLevel(next); setCustom(false); setSize(next.size); setStart(next.start); setGoal(next.goal);
    setObstacles(new Set(next.obstacles)); setPhase("ready"); setPlayer(next.start); setTrail([keyOf(next.start)]);
    setSteps(0); setElapsed(0); setAiIndex(0); setPlan(null); setOutcome(null); setRadar(false);
  }, []);

  const resetRace = useCallback(() => {
    setPhase("ready"); setPlayer(start); setTrail([keyOf(start)]); setSteps(0);
    setElapsed(0); setAiIndex(0); setPlan(null); setOutcome(null); setRadar(false);
  }, [start]);

  const finish = useCallback((who: Exclude<Outcome, null>) => {
    if (phaseRef.current === "over") return;
    phaseRef.current = "over";
    setPhase("over");
    setOutcome(who);
    sfx(who === "player" ? "win" : "lose", sound);
    if (who === "player" && !custom) setCleared(old => ({ ...old, [level.id]: true }));
  }, [sound, custom, level.id]);

  const beginRace = () => {
    const computed = runAStar(size, start, goal, obstacles);
    if (!computed.found) return;
    setPlan(computed); setPlayer(start); setTrail([keyOf(start)]); setSteps(0); setElapsed(0);
    setAiIndex(0); setOutcome(null); setRadar(false); setCount(3); setPhase("countdown");
    sfx("beep", sound);
  };

  // countdown
  useEffect(() => {
    if (phase !== "countdown") return;
    const id = setTimeout(() => {
      if (count > 1) { setCount(c => c - 1); sfx("beep", sound); }
      else { setCount(0); sfx("go", sound); startedAt.current = performance.now(); setPhase("racing"); }
    }, 750);
    return () => clearTimeout(id);
  }, [phase, count, sound]);

  // stopwatch
  useEffect(() => {
    if (phase !== "racing") return;
    const id = setInterval(() => setElapsed(performance.now() - startedAt.current), 60);
    return () => clearInterval(id);
  }, [phase]);

  // AI drone advance
  useEffect(() => {
    if (phase !== "racing" || !plan) return;
    if (aiIndex >= plan.path.length - 1) { finish("ai"); return; }
    const id = setTimeout(() => { setAiIndex(i => i + 1); sfx("ping", sound); }, custom ? 420 : level.aiDelay);
    return () => clearTimeout(id);
  }, [phase, plan, aiIndex, level.aiDelay, custom, sound, finish]);

  const move = useCallback((dx: number, dy: number) => {
    if (phaseRef.current !== "racing") return;
    setPlayer(current => {
      const next = { x: current.x + dx, y: current.y + dy };
      if (next.x < 0 || next.y < 0 || next.x >= size || next.y >= size) return current;
      if (obstacles.has(keyOf(next))) return current;
      sfx("move", sound);
      setSteps(s => {
        const used = s + 1;
        if (keyOf(next) === keyOf(goal)) finish("player");
        else if (used >= battery) finish("drained");
        return used;
      });
      setTrail(t => [...t, keyOf(next)]);
      return next;
    });
  }, [size, obstacles, goal, battery, sound, finish]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const map: Record<string, [number, number]> = {
        ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0],
        w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0],
      };
      const delta = map[event.key] ?? map[event.key.toLowerCase()];
      if (!delta) return;
      if (phaseRef.current !== "racing") return;
      event.preventDefault();
      move(delta[0], delta[1]);
    };
    window.addEventListener("keydown", onKey, { passive: false });
    return () => window.removeEventListener("keydown", onKey);
  }, [move]);

  const editCell = (point: Point) => {
    if (phase === "racing" || phase === "countdown") return;
    const key = keyOf(point);
    if (key === keyOf(start) || key === keyOf(goal)) return;
    setObstacles(old => {
      const next = new Set(old);
      if (paint === "draw") next.add(key); else next.delete(key);
      return next;
    });
    setOutcome(null); setPlan(null); setPhase("ready");
  };

  const randomCity = () => {
    const next = new Set<string>();
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const key = `${x},${y}`;
      if (key !== keyOf(start) && key !== keyOf(goal) && Math.random() < 0.24) next.add(key);
    }
    const probe = runAStar(size, start, goal, next);
    if (!probe.found) return randomCity();
    setObstacles(next); setCustom(true); resetRace();
  };

  const enterCustom = () => { setCustom(true); resetRace(); };
  const nextLevel = () => { const next = levels.find(l => l.id === level.id + 1); if (next) loadLevel(next); };

  const aiPos = plan?.path[Math.min(aiIndex, plan.path.length - 1)] ?? start;
  const aiTrail = new Set((plan?.path.slice(0, aiIndex + 1) ?? []).map(keyOf));
  const trailSet = new Set(trail);
  const hNow = manhattan(aiPos, goal);
  const playerH = manhattan(player, goal);
  const optimal = plan?.cost ?? (preview.found ? preview.cost : 0);
  const radarExplored = new Set((plan?.events ?? []).filter(e => e.status === "explored").map(e => keyOf(e.node)));
  const radarOpen = new Set((plan?.events ?? []).filter(e => e.status === "open").map(e => keyOf(e.node)));
  const radarPath = new Set((plan?.path ?? []).map(keyOf));
  const showRadar = radar && phase === "over" && plan;

  return (
    <section id="race" className="section-shell scroll-mt-20">
      <div className="section-heading">
        <span>Live operation</span>
        <h2>Player vs. AI Rescue Race</h2>
        <p>You drive the Human Rescue Rover. The Autonomous Cyber-Drone runs the real A* algorithm with a Manhattan heuristic. First unit to reach the distress beacon wins.</p>
      </div>

      <div className="race-sectors">
        {levels.map(item => (
          <button key={item.id} className={cn("sector-chip", !custom && level.id === item.id && "sector-active")} onClick={() => loadLevel(item)}>
            <b>{item.name}</b><span>{item.codename}</span>{cleared[item.id] && <i><Trophy /></i>}
          </button>
        ))}
        <button className={cn("sector-chip", custom && "sector-active")} onClick={enterCustom}><b>Custom</b><span>Your city</span></button>
      </div>

      <div className="race-layout">
        <div className="race-main">
          <div className="race-hud">
            <div className="hud-card hud-player"><User /><div><span>Rover steps</span><b>{steps}</b></div></div>
            <div className="hud-card"><Battery /><div><span>Battery</span><b>{remaining} / {battery}</b><i className="battery-bar"><em style={{ width: `${(remaining / battery) * 100}%` }} /></i></div></div>
            <div className="hud-card hud-ai"><Bot /><div><span>Drone h(n)</span><b>{hNow}</b></div></div>
            <div className="hud-card"><Activity /><div><span>Drone path</span><b>{plan ? `${aiIndex} / ${plan.cost}` : "—"}</b></div></div>
            <div className="hud-card"><Timer /><div><span>Race clock</span><b>{fmt(elapsed)}</b></div></div>
          </div>

          <div className="race-stage" onPointerLeave={() => setDragging(false)}>
            <div className="race-grid" style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }} role="grid" aria-label={`${size} by ${size} disaster zone`}>
              {Array.from({ length: size * size }, (_, i) => {
                const point = { x: i % size, y: Math.floor(i / size) };
                const key = keyOf(point);
                const isWall = obstacles.has(key);
                const isPlayer = key === keyOf(player);
                const isAi = phase !== "ready" && key === keyOf(aiPos);
                return (
                  <div
                    key={key}
                    className={cn("race-cell",
                      isWall && "cell-rubble",
                      key === keyOf(goal) && "cell-beacon",
                      !isWall && trailSet.has(key) && "cell-trail",
                      !isWall && aiTrail.has(key) && "cell-ai-trail",
                      showRadar && !isWall && radarExplored.has(key) && "cell-radar-explored",
                      showRadar && !isWall && radarOpen.has(key) && !radarExplored.has(key) && "cell-radar-open",
                      showRadar && radarPath.has(key) && "cell-radar-path",
                    )}
                    role="gridcell"
                    aria-label={`cell ${point.x}, ${point.y}`}
                    onPointerDown={() => { setDragging(true); editCell(point); }}
                    onPointerEnter={() => { if (dragging) editCell(point); }}
                    onPointerUp={() => setDragging(false)}
                  >
                    {key === keyOf(goal) && <Flag />}
                    {isPlayer && <span className="unit unit-player"><User /></span>}
                    {isAi && <span className="unit unit-ai"><Bot /></span>}
                  </div>
                );
              })}
            </div>

            {phase === "countdown" && <div className="race-overlay countdown-overlay"><b>{count > 0 ? count : "GO!"}</b><span>{count > 0 ? "Get ready" : "Rescue underway"}</span></div>}

            {phase === "ready" && (
              <div className="race-overlay">
                <b>{custom ? "Custom Race" : `${level.name} · ${level.codename}`}</b>
                <span>{custom ? "Draw your own rubble, then launch the race." : level.brief}</span>
                <Button size="lg" onClick={beginRace} disabled={!preview.found}><Play /> Start race</Button>
                {!preview.found && <small>No route exists — clear some rubble.</small>}
                <small>Arrow keys / WASD, or use the d-pad.</small>
              </div>
            )}

            {phase === "over" && (
              <div className="race-overlay result-overlay">
                <b className={outcome === "player" ? "win-banner" : "lose-banner"}>
                  {outcome === "player" ? "Rover wins!" : outcome === "ai" ? "Cyber-Drone wins" : "Battery drained"}
                </b>
                <span>
                  {outcome === "player" ? "You reached the survivor before the drone." : outcome === "ai" ? "The drone followed its optimal A* route straight to the beacon." : "The rover ran out of energy before reaching the beacon."}
                </span>
                <div className="result-actions">
                  <Button onClick={beginRace}><RotateCcw /> Rematch</Button>
                  {!custom && level.id < levels.length && <Button variant="outline" onClick={nextLevel}>Next sector <ChevronRight /></Button>}
                  <Button variant="ghost" onClick={() => { setRadar(v => !v); sfx("ping", sound); }}><Radar /> {radar ? "Hide" : "Show"} AI radar vision</Button>
                </div>
              </div>
            )}
          </div>

          <div className="race-controls">
            <div className="dpad" aria-label="Rover d-pad">
              <button onClick={() => move(0, -1)} aria-label="Move up">▲</button>
              <button onClick={() => move(-1, 0)} aria-label="Move left">◀</button>
              <button onClick={() => move(0, 1)} aria-label="Move down">▼</button>
              <button onClick={() => move(1, 0)} aria-label="Move right">▶</button>
            </div>
            <div className="race-buttons">
              <Button onClick={beginRace} disabled={phase === "racing" || phase === "countdown" || !preview.found}><Zap /> {phase === "over" ? "Rematch" : "Start race"}</Button>
              <Button variant="outline" onClick={resetRace}><RotateCcw /> Reset</Button>
              <Button variant="ghost" onClick={randomCity}><Shuffle /> Random city</Button>
              <Button variant={paint === "draw" ? "default" : "ghost"} onClick={() => setPaint("draw")}><Pencil /> Rubble</Button>
              <Button variant={paint === "erase" ? "default" : "ghost"} onClick={() => setPaint("erase")}><Eraser /> Clear</Button>
              <Button variant="ghost" size="icon" title={sound ? "Mute" : "Unmute"} onClick={() => setSound(v => !v)}>{sound ? <Volume2 /> : <VolumeX />}</Button>
            </div>
          </div>
        </div>

        <aside className="race-panel">
          <div className="panel-title"><span>Mission telemetry</span><span className={cn("status-badge", phase === "racing" && "status-searching", outcome === "player" && "status-success", (outcome === "ai" || outcome === "drained") && "status-fail")}>{phase === "ready" ? "Standby" : phase === "countdown" ? "Countdown" : phase === "racing" ? "Racing…" : outcome === "player" ? "Victory" : "Defeat"}</span></div>
          <div className="telemetry-row"><span><User /> Rover</span><b>({player.x}, {player.y})</b></div>
          <div className="telemetry-row"><span>Your h(n) to beacon</span><b>{playerH}</b></div>
          <div className="telemetry-row"><span><Bot /> Drone</span><b>({aiPos.x}, {aiPos.y})</b></div>
          <div className="telemetry-row"><span>Drone h(n) to beacon</span><b>{hNow}</b></div>
          <div className="telemetry-row"><span>A* optimal cost</span><b>{optimal || "—"}</b></div>
          <div className="telemetry-row"><span>Nodes the AI explored</span><b>{plan ? plan.explored : preview.explored}</b></div>
          <div className="formula-badge">f(n) = g(n) + h(n)</div>

          {phase === "over" && plan && (
            <div className="analysis-block">
              <h3>How did the AI {outcome === "player" ? "match" : "beat"} you?</h3>
              <div className="analysis-bars">
                <div><span>Your route</span><i><em style={{ width: `${Math.min(100, (steps / Math.max(steps, plan.cost)) * 100)}%` }} className="bar-player" /></i><b>{steps} moves</b></div>
                <div><span>A* optimal</span><i><em style={{ width: `${Math.min(100, (plan.cost / Math.max(steps, plan.cost)) * 100)}%` }} className="bar-ai" /></i><b>{plan.cost} moves</b></div>
              </div>
              <p>Efficiency: {steps > 0 ? Math.round((plan.cost / steps) * 100) : 0}% of optimal. The drone evaluated {plan.explored} nodes and never wandered into a dead end because every candidate was ranked by f(n) = g(n) + h(n): the energy already spent plus the Manhattan estimate |x − {goal.x}| + |y − {goal.y}| to the beacon. Cells pointing away from the survivor get a high h(n) and sink to the bottom of the open list, so the search stays aimed at the target while remaining optimal.</p>
              <Button variant="outline" onClick={() => setRadar(v => !v)}><Radar /> {radar ? "Hide" : "Toggle"} AI radar vision</Button>
              {radar && <div className="radar-legend"><span><i className="dot-open" />Open list</span><span><i className="dot-explored" />Explored</span><span><i className="dot-path" />Optimal path</span></div>}
            </div>
          )}

          {phase !== "over" && (
            <p className="panel-note"><Gauge /> Every move costs one unit of energy — that is g(n) in gameplay terms. Reach the beacon before the drone and before the battery hits zero.</p>
          )}
        </aside>
      </div>
    </section>
  );
}
