import { useState } from "react";
import { ArrowDown, BrainCircuit, Check, ChevronRight, Compass, Cpu, Gamepad2, Map, Navigation, Plane, Radio, Route, Search, ShieldCheck, Sparkles, Truck, Workflow } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { chebyshev, euclidean, manhattan, type Point } from "@/lib/search";
import { SectionHeading } from "./Simulator";

const concepts = [
  ["State Space", "Every legal arrangement or position the agent could occupy."],
  ["Initial State", "The exact cell where the rescue robot begins its mission."],
  ["Goal State", "The emergency location the robot must successfully reach."],
  ["Operators", "The legal actions: move up, down, left, or right."],
  ["Search Space", "All reachable cells and the connections between them."],
  ["Path Cost", "The accumulated cost g(n); every move costs exactly one."],
  ["Informed Search", "Search guided by knowledge about where the goal may be."],
  ["Heuristic Function", "An estimate h(n) of the remaining distance to the goal."],
  ["A* Algorithm", "A best-first method minimizing f(n) = g(n) + h(n)."],
  ["Optimal Solution", "A valid route with the smallest possible total path cost."],
];

const formulation = [
  ["S₀", "Initial state", "Robot’s starting coordinate", "(1, 8)"],
  ["G", "Goal state", "Emergency destination", "(8, 1)"],
  ["S", "Search space", "All traversable grid cells", "≤ N²"],
  ["A", "Actions", "Up, down, left, right", "4-way"],
  ["c", "Path cost", "Uniform cost per movement", "+1"],
  ["X", "Constraints", "Walls and blocked rubble", "Avoid"],
];

export function ProblemSection() {
  return <section id="problem" className="section-shell scroll-mt-20"><SectionHeading eyebrow="Problem formulation" title="Turn a rescue into a search problem" copy="AI begins by translating a real situation into states, actions, costs, and a measurable goal." /><div className="formulation-grid">{formulation.map(([symbol,title,copy,value]) => <article key={title}><div className="formulation-symbol">{symbol}</div><span>{value}</span><h3>{title}</h3><p>{copy}</p></article>)}</div><div className="problem-strip"><div><Radio /><span>Mission brief</span></div><p>A rescue robot must travel from its initial location to an emergency station. It may move one orthogonal cell at a time, cannot cross rubble, and should minimize the number of moves.</p><code>Find π* = arg min cost(π)</code></div></section>;
}

export function HeuristicSection() {
  const [node, setNode] = useState<Point>({x:2,y:7});
  const goal = {x:8,y:2};
  const dx = Math.abs(node.x-goal.x), dy = Math.abs(node.y-goal.y);
  return <section id="heuristic" className="section-shell scroll-mt-20"><SectionHeading eyebrow="Heuristic deep dive" title="Why does a heuristic help?" copy="Instead of searching equally in every direction, A* uses an estimate to focus effort toward promising states." />
    <div className="heuristic-layout"><div className="pruning-demo"><div className="mini-tree"><div className="tree-root"><BrainCircuit /></div><div className="tree-lines"><i /><i /><i /></div><div className="tree-branches"><span className="dim">12</span><span className="best">6</span><span className="dim">10</span></div><div className="tree-goal"><ArrowDown /><b>Lowest estimated cost</b><small>Expand this branch first</small></div></div><div><span className="kicker">Informed pruning</span><h3>Spend effort where it matters</h3><p>A heuristic does not delete legal routes. It changes the order in which the frontier is explored, so promising nodes are considered sooner.</p></div></div>
    <div className="heuristic-lab"><div className="lab-grid"><div className="axis-label y">Y {node.y}</div><div className="coord-field">{Array.from({length:100},(_,i)=>{const p={x:i%10,y:Math.floor(i/10)}; const isNode=p.x===node.x&&p.y===node.y,isGoal=p.x===goal.x&&p.y===goal.y;return <span key={i} className={isNode?"coord-node":isGoal?"coord-goal":""}>{isNode?"N":isGoal?"G":""}</span>})}</div><div className="axis-label">X {node.x}</div><Slider value={[node.x]} min={0} max={9} step={1} onValueChange={v=>setNode(n=>({...n,x:v[0]??n.x}))}/><Slider value={[node.y]} min={0} max={9} step={1} onValueChange={v=>setNode(n=>({...n,y:v[0]??n.y}))}/></div>
      <div className="heuristic-options"><div><span>Current N ({node.x},{node.y})</span><span>Goal G ({goal.x},{goal.y})</span></div><HeuristicCard name="Manhattan" formula="|Δx| + |Δy|" value={manhattan(node,goal)} note={`${dx} + ${dy}`} active/><HeuristicCard name="Euclidean" formula="√(Δx² + Δy²)" value={euclidean(node,goal)} note={`√(${dx}² + ${dy}²)`}/><HeuristicCard name="Chebyshev" formula="max(|Δx|, |Δy|)" value={chebyshev(node,goal)} note={`max(${dx}, ${dy})`}/></div></div></div>
    <div className="admissible-card"><ShieldCheck /><div><span>Admissibility guarantee</span><h3>h(n) ≤ h*(n)</h3><p>For orthogonal movement with unit cost, Manhattan distance never overestimates the true shortest remaining route. Obstacles may force extra moves—but never fewer—so A* remains optimal.</p></div></div>
  </section>;
}

function HeuristicCard({name,formula,value,note,active=false}:{name:string;formula:string;value:number;note:string;active?:boolean}) { return <article className={active?"heuristic-card active":"heuristic-card"}><div><span>{name}</span>{active&&<b>Used by A*</b>}</div><code>{formula}</code><p>{note}</p><strong>{Number.isInteger(value)?value:value.toFixed(2)}</strong></article>; }

export function ConceptsSection() {
  const flow = ["Problem","State space","Initial state","Generate neighbors","Calculate g / h / f","Select lowest f(n)","Goal test","Optimal path"];
  return <section id="concepts" className="section-shell scroll-mt-20"><SectionHeading eyebrow="Foundation of AI" title="Ten concepts behind the mission" copy="The simulator turns abstract search vocabulary into visible, inspectable decisions." /><div className="concept-grid">{concepts.map(([title,copy],index)=><article key={title}><span>{String(index+1).padStart(2,"0")}</span><h3>{title}</h3><p>{copy}</p></article>)}</div><div className="flow-panel"><div><span className="kicker">Where AI appears in this website</span><h3>From problem to optimal path</h3></div><div className="flow-row">{flow.map((item,index)=><div key={item} className="flow-step"><span>{index+1}</span><b>{item}</b>{index<flow.length-1&&<ChevronRight />}</div>)}</div></div></section>;
}

export function CodeAndAbout() {
  const applications = [[<Navigation/>,"GPS route planning"],[<Cpu/>,"Robot navigation"],[<Gamepad2/>,"Game AI"],[<Truck/>,"Emergency logistics"],[<Plane/>,"Flight path planning"]];
  return <><section id="code" className="section-shell scroll-mt-20"><SectionHeading eyebrow="Code logic" title="A* in plain language" copy="Every animated event in the simulator comes from these same algorithmic decisions." /><div className="code-layout"><div className="pseudo"><div className="code-title"><span /><span /><span /><b>astar.ts</b></div><ol><li><code>open ← priority queue with start</code><span>Begin with one candidate.</span></li><li><code>while open is not empty</code><span>Continue while routes remain.</span></li><li><code>current ← lowest f(n)</code><span>Choose the best estimate.</span></li><li><code>if current = goal, reconstruct</code><span>Follow parents back to start.</span></li><li><code>for each valid neighbor</code><span>Try four legal movements.</span></li><li><code>tentative g ← g(current) + 1</code><span>Measure the new route cost.</span></li><li><code>update parent, g, h, f</code><span>Keep the better discovery.</span></li></ol></div><div className="logic-flow"><Workflow/><h3>Decision loop</h3>{["Pop lowest f(n)","Check goal","Expand neighbors","Update priority queue","Repeat"].map((step,i)=><div key={step}><span>{i+1}</span><b>{step}</b>{i<4&&<ArrowDown/>}</div>)}</div></div>
    <div className="applications"><span className="kicker">Real-world applications</span><div>{applications.map(([icon,label])=><article key={String(label)}>{icon}<span>{label}</span></article>)}</div></div></section>
    <section id="about" className="about-section scroll-mt-20"><div className="section-shell"><div className="about-grid"><div><span className="kicker">Built for learning</span><h2>A complete search laboratory.<br/>No black boxes.</h2><p>Pure TypeScript algorithms, React interface, semantic CSS, browser-native animation and sound. Zero external APIs. Zero machine learning. Every path and statistic is computed locally from the grid you create.</p><div className="tech-row"><span>React</span><span>TypeScript</span><span>A* + BFS</span><span>Client-only</span></div></div><div className="outcomes"><h3>Learning outcomes</h3>{["Formulate a state-space search problem","Calculate g(n), h(n), and f(n)","Trace a real A* priority queue","Explain heuristic admissibility","Compare informed and uninformed search","Connect search to practical AI systems"].map(item=><p key={item}><Check/>{item}</p>)}</div></div></div></section></>;
}