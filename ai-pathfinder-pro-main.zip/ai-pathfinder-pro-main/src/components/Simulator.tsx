import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Blocks, Bot, Check, ChevronDown, CircleDot, Eraser, Flag, Gauge, Grid3X3, Pause, Play, RotateCcw, Shuffle, SkipForward, Sparkles, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import { challenges, type Challenge } from "@/lib/challenges";
import { keyOf, manhattan, runAStar, runBfs, type Point, type SearchResult } from "@/lib/search";

type Mode = "start" | "goal" | "wall" | "erase";
type Status = "Idle" | "Searching…" | "Goal reached!" | "No path found";
const speedValues = [700, 260, 80, 0];
const speedNames = ["Slow", "Medium", "Fast", "Instant"];

function tone(kind: "start" | "success" | "fail", enabled: boolean) {
  if (!enabled || typeof window === "undefined") return;
  const AudioContextClass = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return;
  const context = new AudioContextClass();
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.frequency.value = kind === "success" ? 660 : kind === "fail" ? 170 : 330;
  gain.gain.setValueAtTime(0.035, context.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.15);
  oscillator.connect(gain).connect(context.destination);
  oscillator.start(); oscillator.stop(context.currentTime + 0.16);
}

const defaultStart = { x: 1, y: 8 };
const defaultGoal = { x: 8, y: 1 };

export function Simulator() {
  const [size, setSize] = useState(10);
  const [start, setStart] = useState<Point>(defaultStart);
  const [goal, setGoal] = useState<Point>(defaultGoal);
  const [obstacles, setObstacles] = useState<Set<string>>(new Set(challenges[0]?.obstacles ?? []));
  const [mode, setMode] = useState<Mode>("wall");
  const [speed, setSpeed] = useState(2);
  const [sound, setSound] = useState(true);
  const [status, setStatus] = useState<Status>("Idle");
  const [eventIndex, setEventIndex] = useState(0);
  const [result, setResult] = useState<SearchResult | null>(null);
  const [displayPath, setDisplayPath] = useState<Set<string>>(new Set());
  const [inspected, setInspected] = useState<Point>(defaultStart);
  const [comparison, setComparison] = useState<{ aStar: SearchResult; bfs: SearchResult } | null>(null);
  const [activeChallenge, setActiveChallenge] = useState(1);
  const [completions, setCompletions] = useState<Record<number, number>>({});
  const [dragging, setDragging] = useState(false);
  const [paused, setPaused] = useState(false);
  const [traceOpen, setTraceOpen] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearTimer = () => { if (timer.current) clearTimeout(timer.current); timer.current = null; };
  const clearRun = useCallback(() => {
    clearTimer(); setResult(null); setEventIndex(0); setDisplayPath(new Set()); setStatus("Idle"); setPaused(false);
  }, []);
  useEffect(() => () => clearTimer(), []);

  const visibleEvents = result?.events.slice(0, eventIndex) ?? [];
  const explored = useMemo(() => new Set(visibleEvents.filter(e => e.status === "explored").map(e => keyOf(e.node))), [visibleEvents]);
  const open = useMemo(() => {
    const values = new Set(visibleEvents.filter(e => e.status === "open").map(e => keyOf(e.node)));
    explored.forEach(k => values.delete(k)); return values;
  }, [visibleEvents, explored]);
  const latestScores = result?.scores ?? {};

  const finish = useCallback((search: SearchResult) => {
    setDisplayPath(new Set(search.path.map(keyOf)));
    setStatus(search.found ? "Goal reached!" : "No path found");
    if (search.found) setCompletions(old => ({ ...old, [activeChallenge]: Math.min(old[activeChallenge] ?? Number.POSITIVE_INFINITY, search.cost) }));
    tone(search.found ? "success" : "fail", sound);
  }, [activeChallenge, sound]);

  useEffect(() => {
    clearTimer();
    if (!result || paused || status !== "Searching…") return;
    if (eventIndex >= result.events.length) { finish(result); return; }
    const delay = speedValues[speed];
    if (delay === 0) { setEventIndex(result.events.length); finish(result); return; }
    timer.current = setTimeout(() => setEventIndex(i => i + 1), delay);
    return clearTimer;
  }, [result, eventIndex, paused, speed, status, finish]);

  const startRun = () => {
    clearTimer(); const next = runAStar(size, start, goal, obstacles);
    setResult(next); setDisplayPath(new Set()); setEventIndex(0); setPaused(false); setStatus("Searching…"); tone("start", sound);
  };
  const step = () => {
    let next = result;
    if (!next || status === "Goal reached!" || status === "No path found") { next = runAStar(size, start, goal, obstacles); setResult(next); setEventIndex(0); setDisplayPath(new Set()); }
    setPaused(true); setStatus("Searching…");
    const newIndex = Math.min((next ? eventIndex : 0) + 1, next.events.length);
    setEventIndex(newIndex);
    if (newIndex >= next.events.length) finish(next);
  };
  const applyCell = (point: Point) => {
    if (status === "Searching…" && !paused) return;
    clearRun(); const key = keyOf(point);
    if (mode === "start" && key !== keyOf(goal)) { setStart(point); setInspected(point); setObstacles(old => { const n = new Set(old); n.delete(key); return n; }); }
    if (mode === "goal" && key !== keyOf(start)) { setGoal(point); setInspected(point); setObstacles(old => { const n = new Set(old); n.delete(key); return n; }); }
    if (mode === "wall" && key !== keyOf(start) && key !== keyOf(goal)) setObstacles(old => new Set(old).add(key));
    if (mode === "erase") setObstacles(old => { const n = new Set(old); n.delete(key); return n; });
  };
  const randomize = () => {
    clearRun(); const next = new Set<string>();
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (Math.random() < 0.22 && keyOf({x,y}) !== keyOf(start) && keyOf({x,y}) !== keyOf(goal)) next.add(`${x},${y}`);
    setObstacles(next); setActiveChallenge(0); setComparison(null);
  };
  const loadChallenge = (challenge: Challenge) => {
    clearRun(); setSize(challenge.size); setStart(challenge.start); setGoal(challenge.goal); setInspected(challenge.start); setObstacles(new Set(challenge.obstacles)); setActiveChallenge(challenge.id); setComparison(null); document.querySelector("#simulator")?.scrollIntoView({ behavior: "smooth" });
  };
  const resize = (next: number) => { clearRun(); setSize(next); setStart({x:1,y:next-2}); setGoal({x:next-2,y:1}); setInspected({x:1,y:next-2}); setObstacles(new Set()); setActiveChallenge(0); };
  const compare = () => setComparison({ aStar: runAStar(size, start, goal, obstacles), bfs: runBfs(size, start, goal, obstacles) });
  const currentG = latestScores[keyOf(inspected)];
  const h = manhattan(inspected, goal);

  return <>
    <section id="simulator" className="section-shell scroll-mt-20">
      <SectionHeading eyebrow="Mission control" title="A* Search Simulator" copy="Design the terrain, inspect the math, then watch an informed agent find the lowest-cost rescue path." />
      <div className="sim-layout">
        <div className="sim-main">
          <div className="control-bar">
            <div className="mode-group" aria-label="Grid editing mode">
              <ModeButton active={mode === "start"} onClick={() => setMode("start")} icon={<Bot />} label="Start" />
              <ModeButton active={mode === "goal"} onClick={() => setMode("goal")} icon={<Flag />} label="Goal" />
              <ModeButton active={mode === "wall"} onClick={() => setMode("wall")} icon={<Blocks />} label="Walls" />
              <ModeButton active={mode === "erase"} onClick={() => setMode("erase")} icon={<Eraser />} label="Erase" />
            </div>
            <label className="size-control"><Grid3X3 /><span>Grid</span><select value={size} onChange={e => resize(Number(e.target.value))}>{[10,11,12,13,14,15].map(v => <option key={v} value={v}>{v}×{v}</option>)}</select></label>
          </div>
          <div className="grid-wrap" onPointerLeave={() => setDragging(false)}>
            <div className="rescue-grid" style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }} role="grid" aria-label={`${size} by ${size} rescue map`}>
              {Array.from({ length: size * size }, (_, i) => {
                const point = { x: i % size, y: Math.floor(i / size) }; const key = keyOf(point);
                const kind = key === keyOf(start) ? "start" : key === keyOf(goal) ? "goal" : obstacles.has(key) ? "wall" : displayPath.has(key) ? "path" : explored.has(key) ? "explored" : open.has(key) ? "open" : "empty";
                return <button key={key} className={cn("grid-cell", `cell-${kind}`, key === keyOf(inspected) && "cell-inspected")} aria-label={`${kind} cell ${point.x}, ${point.y}`} onPointerDown={e => { e.preventDefault(); setDragging(true); applyCell(point); setInspected(point); }} onPointerEnter={() => { setInspected(point); if (dragging && (mode === "wall" || mode === "erase")) applyCell(point); }} onPointerUp={() => setDragging(false)}>{kind === "start" ? <Bot /> : kind === "goal" ? <Flag /> : kind === "wall" ? <span className="wall-mark" /> : kind === "path" ? <Sparkles /> : null}</button>;
              })}
            </div>
          </div>
          <div className="legend"><span><i className="legend-start" />Start</span><span><i className="legend-goal" />Goal</span><span><i className="legend-open" />Open</span><span><i className="legend-explored" />Explored</span><span><i className="legend-path" />Path</span><span><i className="legend-wall" />Obstacle</span></div>
          <div className="action-row">
            <Button onClick={startRun} disabled={status === "Searching…" && !paused} className="run-button"><Play /> Run A*</Button>
            <Button variant="outline" onClick={step}><SkipForward /> Step forward</Button>
            {status === "Searching…" && <Button variant="outline" size="icon" title={paused ? "Resume" : "Pause"} onClick={() => setPaused(v => !v)}>{paused ? <Play /> : <Pause />}</Button>}
            <Button variant="ghost" onClick={() => { clearRun(); setObstacles(new Set(challenges[0]?.obstacles ?? [])); setStart(defaultStart); setGoal(defaultGoal); }}><RotateCcw /> Reset</Button>
            <Button variant="ghost" onClick={randomize}><Shuffle /> Random map</Button>
            <Button variant="ghost" onClick={() => { clearRun(); setObstacles(new Set()); }}><Eraser /> Clear walls</Button>
          </div>
          <div className="speed-row"><Gauge /><span>Animation</span><Slider value={[speed]} min={0} max={3} step={1} onValueChange={v => setSpeed(v[0] ?? 2)} aria-label="Animation speed" /><strong>{speedNames[speed] ?? "Fast"}</strong><Button variant="ghost" size="icon" onClick={() => setSound(v => !v)} title={sound ? "Mute sounds" : "Enable sounds"}>{sound ? <Volume2 /> : <VolumeX />}</Button></div>
        </div>
        <aside className="analyzer-panel">
          <div className="panel-title"><span>Live node inspector</span><StatusBadge status={status} /></div>
          <div className="node-focus"><div><span>Current node</span><strong>({inspected.x}, {inspected.y})</strong></div><div className="direction" style={{ transform: `rotate(${Math.atan2(goal.y-inspected.y, goal.x-inspected.x) * 180 / Math.PI}deg)` }}>→</div><div><span>Goal</span><strong>({goal.x}, {goal.y})</strong></div></div>
          <div className="formula-stack">
            <FormulaRow symbol="g(n)" label="Actual cost" value={currentG === undefined ? "—" : String(currentG)} />
            <FormulaRow symbol="h(n)" label="Heuristic" value={String(h)} accent />
            <div className="calculation">|{inspected.x} − {goal.x}| + |{inspected.y} − {goal.y}| = <b>{h}</b></div>
            <FormulaRow symbol="f(n)" label="Total priority" value={currentG === undefined ? "—" : String(currentG + h)} />
          </div>
          <p className="panel-note">h(n) estimates the remaining distance from the current node to the goal.</p>
          <div className="stats-grid">
            <Stat label="Path found" value={result && eventIndex >= result.events.length ? result.found ? "Yes" : "No" : "—"} />
            <Stat label="Path cost" value={displayPath.size ? String(Math.max(0, displayPath.size - 1)) : "—"} />
            <Stat label="Explored" value={String(explored.size)} />
            <Stat label="Open list" value={String(open.size)} />
            <Stat label="Execution" value={result ? `${result.duration.toFixed(2)} ms` : "—"} />
            <Stat label="Heuristic" value="Manhattan" />
          </div>
          <div className="formula-badge">f(n) = g(n) + h(n)</div>
        </aside>
      </div>
      <Collapsible open={traceOpen} onOpenChange={setTraceOpen} className="trace-panel">
        <CollapsibleTrigger asChild><Button variant="ghost" className="trace-trigger"><span><CircleDot /> Execution trace <b>{visibleEvents.length} events</b></span><ChevronDown className={traceOpen ? "rotate-180" : ""} /></Button></CollapsibleTrigger>
        <CollapsibleContent><div className="trace-scroll"><table><thead><tr><th>Step</th><th>Node</th><th>g(n)</th><th>h(n)</th><th>f(n)</th><th>Parent</th><th>Status</th></tr></thead><tbody>{visibleEvents.map((event, index) => <tr key={`${event.step}-${index}`}><td>{event.step}</td><td>({event.node.x}, {event.node.y})</td><td>{event.g}</td><td>{event.h}</td><td>{event.f}</td><td>{event.parent ? `(${event.parent.x}, ${event.parent.y})` : "—"}</td><td><span className={`trace-${event.status}`}>{event.status === "open" ? "Added to open" : "Explored"}</span></td></tr>)}</tbody></table>{!visibleEvents.length && <p className="empty-trace">Run or step through A* to generate a mathematical trace.</p>}</div></CollapsibleContent>
      </Collapsible>
    </section>

    <section id="challenges" className="section-shell scroll-mt-20"><SectionHeading eyebrow="Practice lab" title="Five rescue challenges" copy="Load a designed scenario, run your strategy, and improve the route cost." /><div className="challenge-grid">{challenges.map(challenge => <article key={challenge.id} className={cn("challenge-card", activeChallenge === challenge.id && "active-challenge")}><div className="challenge-top"><span>0{challenge.id}</span><b>{challenge.difficulty}</b></div><h3>{challenge.name}</h3><p>{challenge.description}</p><div className="challenge-meta"><span>S ({challenge.start.x},{challenge.start.y})</span><span>G ({challenge.goal.x},{challenge.goal.y})</span></div><Button variant={activeChallenge === challenge.id ? "default" : "outline"} onClick={() => loadChallenge(challenge)}>{activeChallenge === challenge.id ? <Check /> : <Play />}{activeChallenge === challenge.id ? "Loaded" : "Load map"}</Button>{completions[challenge.id] !== undefined && <small>Best path cost: {completions[challenge.id]}</small>}</article>)}</div></section>

    <section id="comparison" className="section-shell scroll-mt-20"><SectionHeading eyebrow="Algorithm lab" title="BFS vs A*: head to head" copy="Run both algorithms against the exact same map. The results below are calculated live—not scripted." /><div className="comparison-shell"><div className="comparison-intro"><h3>Uninformed Search <span>vs</span> Informed Search</h3><p>BFS expands evenly in every direction. A* adds h(n), prioritizing nodes that appear closer to the goal while preserving optimality.</p><Button onClick={compare}><Gauge /> Compare on current map</Button></div><div className="comparison-results">{comparison ? <>{<AlgorithmResult name="Breadth-First Search" tag="Uninformed" result={comparison.bfs} max={Math.max(comparison.bfs.explored, comparison.aStar.explored)} />}{<AlgorithmResult name="A* Search" tag="Informed" result={comparison.aStar} max={Math.max(comparison.bfs.explored, comparison.aStar.explored)} />}</> : <div className="comparison-empty"><Sparkles /><span>Ready for a fair test</span><small>Current grid · same start · same goal · same obstacles</small></div>}</div></div></section>
  </>;
}

export function SectionHeading({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) { return <div className="section-heading"><span>{eyebrow}</span><h2>{title}</h2><p>{copy}</p></div>; }
function ModeButton({active,onClick,icon,label}:{active:boolean;onClick:()=>void;icon:React.ReactNode;label:string}) { return <Button size="sm" variant={active ? "default" : "ghost"} onClick={onClick}>{icon}{label}</Button>; }
function StatusBadge({status}:{status:Status}) { return <span className={cn("status-badge", status === "Searching…" && "status-searching", status === "Goal reached!" && "status-success", status === "No path found" && "status-fail")}>{status}</span>; }
function FormulaRow({symbol,label,value,accent=false}:{symbol:string;label:string;value:string;accent?:boolean}) { return <div className={cn("formula-row", accent && "formula-accent")}><div><b>{symbol}</b><span>{label}</span></div><strong>{value}</strong></div>; }
function Stat({label,value}:{label:string;value:string}) { return <div className="stat"><span>{label}</span><b>{value}</b></div>; }
function AlgorithmResult({name,tag,result,max}:{name:string;tag:string;result:SearchResult;max:number}) { return <article className={tag === "Informed" ? "algo-card informed" : "algo-card"}><div><span>{tag}</span><h3>{name}</h3></div><div className="metric"><span>Nodes explored</span><b>{result.explored}</b></div><div className="metric-bar"><i style={{width:`${max ? result.explored/max*100 : 0}%`}} /></div><div className="algo-stats"><span>Path length <b>{result.found ? result.cost : "—"}</b></span><span>Trace events <b>{result.steps}</b></span><span>Result <b>{result.found ? "Found" : "No path"}</b></span></div></article>; }