import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowDown, BookOpen, Brain, Flag, Gamepad2, Menu, Route as RouteIcon, Ruler, Sparkles, Star, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Simulator } from "@/components/Simulator";
import { RescueRace } from "@/components/RescueRace";
import { CodeAndAbout, ConceptsSection, HeuristicSection, ProblemSection } from "@/components/EducationSections";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "AI Rescue Mission | Player vs A* Rescue Race" },
    { name: "description", content: "Race a real A* pathfinding drone across disaster grids and learn heuristic search through play." },
    { property: "og:title", content: "AI Rescue Mission | Player vs A* Rescue Race" },
    { property: "og:description", content: "Drive the rescue rover against an autonomous A* drone and inspect the heuristic search behind every move." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

const nav: Array<[string, string]> = [["Home","home"],["Rescue Race","race"],["Field Manual","manual"],["Problem","problem"],["A* Simulator","simulator"],["Heuristic","heuristic"],["Challenges","challenges"],["BFS vs A*","comparison"],["AI Concepts","concepts"],["About","about"]];

function Index() {
  const [menu, setMenu] = useState(false);
  const [active, setActive] = useState("home");
  const [manual, setManual] = useState(false);
  useEffect(()=>{const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)setActive(e.target.id)}),{rootMargin:"-25% 0px -65%"});nav.forEach(([,id])=>{const el=document.getElementById(id);if(el)observer.observe(el)});return()=>observer.disconnect()},[manual]);
  const manualIds = ["problem","simulator","heuristic","challenges","comparison","concepts","code","about"];
  const go = (id:string) => {
    setMenu(false);
    if (manualIds.includes(id) && !manual) { setManual(true); setTimeout(()=>document.getElementById(id)?.scrollIntoView({behavior:"smooth"}), 80); return; }
    document.getElementById(id)?.scrollIntoView({behavior:"smooth"});
  };
  return <main>
    <header className="site-header"><button className="brand" onClick={()=>go("home")} aria-label="AI Rescue Mission home"><span><Brain/></span><div><b>AI RESCUE</b><small>MISSION</small></div></button><nav>{nav.map(([label,id])=><button key={id} className={active===id?"active":""} onClick={()=>go(id)}>{label}</button>)}</nav><Button variant="ghost" size="icon" className="menu-button" onClick={()=>setMenu(v=>!v)} aria-label="Toggle navigation">{menu?<X/>:<Menu/>}</Button>{menu&&<div className="mobile-nav">{nav.map(([label,id])=><button key={id} className={active===id?"active":""} onClick={()=>go(id)}>{label}</button>)}</div>}</header>
    <section id="home" className="hero"><div className="hero-grid"/><div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/><div className="hero-content"><div className="hero-badge"><span/> Foundation of Artificial Intelligence</div><h1>AI RESCUE<br/><span>MISSION</span></h1><p className="hero-question">Can you guide the rescue robot using Artificial Intelligence?</p><p className="hero-copy">An interactive demonstration of Informed Search Strategies using the A* algorithm and heuristic functions.</p><div className="hero-actions"><Button size="lg" onClick={()=>go("race")}><Sparkles/> Start rescue</Button><Button size="lg" variant="outline" onClick={()=>go("heuristic")}><Ruler/> Learn heuristics</Button></div></div><div className="hero-console" aria-hidden="true"><div className="radar"><span className="radar-sweep"/><i className="robot-dot"><Brain/></i><i className="goal-dot"><Flag/></i><i className="route-line"/></div><div className="console-readout"><span>SEARCH ONLINE</span><b>f(n) = g(n) + h(n)</b><small>MANHATTAN HEURISTIC</small></div></div><div className="scroll-cue"><ArrowDown/><span>Explore the mission</span></div></section>
    <section className="feature-band"><div>{[[<Brain/>,"Informed Search","Prioritize promising states"],[<Ruler/>,"Heuristic Function","Estimate distance to goal"],[<Star/>,"A* Algorithm","Balance cost and estimate"],[<RouteIcon/>,"Path Finding","Recover the optimal route"]].map(([icon,title,copy])=><article key={String(title)}>{icon}<div><h3>{title}</h3><p>{copy}</p></div></article>)}</div></section>
    <RescueRace/>
    <section id="manual" className="section-shell manual-toggle scroll-mt-20">
      <div><h2><BookOpen/> Field Manual · AI Concepts</h2><p>The full academic layer: problem formulation, the A* simulator, heuristic analysis, BFS comparison, pseudocode and learning outcomes.</p></div>
      <Button size="lg" variant={manual?"outline":"default"} onClick={()=>setManual(v=>!v)}>{manual?<X/>:<Gamepad2/>}{manual?"Hide field manual":"Open field manual"}</Button>
    </section>
    {manual && <><ProblemSection/><Simulator/><HeuristicSection/><ConceptsSection/><CodeAndAbout/></>}
    <footer><div className="brand"><span><Brain/></span><div><b>AI RESCUE</b><small>MISSION</small></div></div><p>Foundation of Artificial Intelligence · Interactive heuristic search laboratory</p><span>Designed for curious minds.</span></footer>
  </main>;
}